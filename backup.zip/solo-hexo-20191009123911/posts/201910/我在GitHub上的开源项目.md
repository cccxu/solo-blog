title: 我在 GitHub 上的开源项目
date: '2019-10-09 12:29:10'
updated: '2019-10-09 12:29:10'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [cccxu.github.io](https://github.com/cccxu/cccxu.github.io) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/cccxu.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/cccxu.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/cccxu.github.io/network/members "分叉数")</span>





---

### 2. [pomodoro](https://github.com/cccxu/pomodoro) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/pomodoro/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/pomodoro/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/pomodoro/network/members "分叉数")</span>

A simple pomodoro app with white noise and todo list.



---

### 3. [login](https://github.com/cccxu/login) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/login/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/login/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/login/network/members "分叉数")</span>





---

### 4. [WeatherApp](https://github.com/cccxu/WeatherApp) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/WeatherApp/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/WeatherApp/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/WeatherApp/network/members "分叉数")</span>





---

### 5. [ASimpleGame](https://github.com/cccxu/ASimpleGame) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/ASimpleGame/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/ASimpleGame/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/ASimpleGame/network/members "分叉数")</span>





---

### 6. [AndroidProjects](https://github.com/cccxu/AndroidProjects) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/AndroidProjects/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/AndroidProjects/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/AndroidProjects/network/members "分叉数")&nbsp;&nbsp;[🏠`HomePage`](HomePage "项目主页")</span>

mobile app dev



---

### 7. [Basic-graphics-generation-algorithm--python](https://github.com/cccxu/Basic-graphics-generation-algorithm--python) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/Basic-graphics-generation-algorithm--python/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/Basic-graphics-generation-algorithm--python/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/Basic-graphics-generation-algorithm--python/network/members "分叉数")</span>

包含了直线、圆形、椭圆、区域填充、直线的裁剪算法的python实现



---

### 8. [javafx-course-selection](https://github.com/cccxu/javafx-course-selection) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/cccxu/javafx-course-selection/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/cccxu/javafx-course-selection/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/cccxu/javafx-course-selection/network/members "分叉数")</span>

利用javafx和mysql实现的简单的本地选课程序

